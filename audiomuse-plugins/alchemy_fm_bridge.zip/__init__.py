"""AudioMuse-native channel designer — preview programming, then deploy to Alchemy FM."""

from __future__ import annotations

import base64
import html
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from flask import Blueprint, request, redirect, url_for

from plugin.api import (
    get_db,
    get_score_data_by_ids,
    get_setting,
    set_setting,
    render_page,
    manage_plugins_url,
    logger,
    table,
)

PLUGIN_VERSION = "2.3.2"
PLUGIN_ID = "alchemy_fm_bridge"

ALCHEMY_FM_USER_AGENT = (
    "AlchemyFmBridge/2.3 AudioMuse-Plugin (+https://github.com/MMagTech/alchemyfm)"
)

# ---------------------------------------------------------------------------
# Errors + HTTP clients
# ---------------------------------------------------------------------------


def _friendly_http_error(status: int, body: str) -> str:
    lower = body.lower()
    if (
        "browser's signature" in lower
        or "cloudflare" in lower
        or "cf-ray" in lower
        or "just a moment" in lower
    ):
        return (
            "Cloudflare blocked the AudioMuse server from reaching Alchemy FM. "
            "The plugin calls the API from your AudioMuse container, not your browser. "
            "Fix: add a Cloudflare WAF skip rule for path /api/admin/* (or from your "
            "AudioMuse server IP), use a direct/LAN URL that bypasses Cloudflare in "
            "plugin settings, or turn off Bot Fight Mode for admin API routes."
        )
    try:
        parsed = json.loads(body)
        if isinstance(parsed, dict):
            if parsed.get("detail"):
                return str(parsed["detail"])
            if parsed.get("error"):
                return str(parsed["error"])
    except json.JSONDecodeError:
        pass
    if "<html" in lower:
        return f"Alchemy FM returned HTTP {status} (HTML error page — often Cloudflare or a reverse proxy)."
    text = re.sub(r"<[^>]+>", " ", body)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:500] or f"HTTP {status}"


class ChannelDesignerError(Exception):
    def __init__(self, message: str, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


class AlchemyFmClient:
    def __init__(self, base_url: str, username: str, password: str, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        token = base64.b64encode(f"{username}:{password}".encode()).decode("ascii")
        self.headers = {
            "Authorization": f"Basic {token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": ALCHEMY_FM_USER_AGENT,
            "Accept-Language": "en-US,en;q=0.9",
        }

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(url, data=data, headers=self.headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                body = resp.read().decode("utf-8")
                return json.loads(body) if body else None
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise ChannelDesignerError(
                _friendly_http_error(exc.code, detail), status=exc.code
            ) from exc
        except urllib.error.URLError as exc:
            raise ChannelDesignerError(
                f"Could not reach Alchemy FM at {self.base_url}: {exc.reason}"
            ) from exc

    def test_connection(self) -> list[dict[str, Any]]:
        stations = self._request("GET", "/api/admin/stations")
        if not isinstance(stations, list):
            raise ChannelDesignerError("Unexpected response from /api/admin/stations")
        return stations

    def find_station_by_slug(self, slug: str) -> dict[str, Any] | None:
        slug = slug.strip().lower()
        for station in self.test_connection():
            if str(station.get("slug", "")).lower() == slug:
                return station
        return None

    def create_station(self, payload: dict[str, Any]) -> dict[str, Any]:
        result = self._request("POST", "/api/admin/stations", payload)
        if not isinstance(result, dict):
            raise ChannelDesignerError("Unexpected response when creating station")
        return result

    def update_station(self, station_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        result = self._request("PUT", f"/api/admin/stations/{station_id}", payload)
        if not isinstance(result, dict):
            raise ChannelDesignerError("Unexpected response when updating station")
        return result

    def bootstrap_station(self, station_id: int) -> dict[str, Any]:
        result = self._request("POST", f"/api/admin/stations/{station_id}/bootstrap")
        if not isinstance(result, dict):
            raise ChannelDesignerError("Unexpected response when bootstrapping station")
        return result

    def delete_station(self, station_id: int) -> None:
        self._request("DELETE", f"/api/admin/stations/{int(station_id)}")

    def refresh_queue(self, station_id: int) -> dict[str, Any]:
        result = self._request("POST", f"/api/admin/stations/{int(station_id)}/refresh-queue")
        if not isinstance(result, dict):
            raise ChannelDesignerError("Unexpected response when refreshing station queue")
        return result

    def push_station(
        self,
        payload: dict[str, Any],
        *,
        slug: str | None = None,
        bootstrap: bool = True,
    ) -> tuple[dict[str, Any], str]:
        target_slug = (slug or payload.get("slug") or "").strip().lower()
        existing = self.find_station_by_slug(target_slug) if target_slug else None
        if existing:
            station_id = int(existing["id"])
            update_fields = {
                key: value
                for key, value in payload.items()
                if key not in ("slug", "bootstrap_queue")
            }
            station = self.update_station(station_id, update_fields)
            action = "updated"
        else:
            station = self.create_station(payload)
            station_id = int(station["id"])
            action = "created"
        if bootstrap and payload.get("bootstrap_queue", True):
            station = self.bootstrap_station(station_id)
        return station, action


def _audiomuse_base_url() -> str:
    custom = (get_setting("audiomuse_api_url") or "").strip().rstrip("/")
    if custom:
        return custom
    try:
        from plugin.api import config as plugin_config

        host = getattr(plugin_config, "AUDIOMUSE_CONTROL_HOST", "") or ""
        port = getattr(plugin_config, "AUDIOMUSE_CONTROL_PORT", "") or ""
        if host and port:
            return f"http://{host}:{port}".rstrip("/")
    except Exception:
        pass
    try:
        from flask import has_request_context

        if has_request_context():
            return request.host_url.rstrip("/")
    except Exception:
        pass
    return "http://127.0.0.1:8000"


def _audiomuse_token() -> str:
    try:
        from plugin.api import config as plugin_config

        token = getattr(plugin_config, "AUDIOMUSE_API_TOKEN", "") or ""
        if token:
            return str(token)
    except Exception:
        pass
    return str(get_setting("audiomuse_api_token") or "")


def _audiomuse_headers() -> dict[str, str]:
    headers = {"Accept": "application/json"}
    token = _audiomuse_token()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def audiomuse_get(path: str, *, params: dict[str, str] | None = None, timeout: float = 60.0) -> Any:
    query = "?" + urllib.parse.urlencode(params) if params else ""
    url = f"{_audiomuse_base_url()}{path}{query}"
    req = urllib.request.Request(url, headers=_audiomuse_headers(), method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise ChannelDesignerError(detail or f"AudioMuse API HTTP {exc.code}", status=exc.code) from exc
    except urllib.error.URLError as exc:
        raise ChannelDesignerError(f"Could not reach AudioMuse API: {exc.reason}") from exc


def audiomuse_post(path: str, payload: dict[str, Any], *, timeout: float = 120.0) -> Any:
    url = f"{_audiomuse_base_url()}{path}"
    data = json.dumps(payload).encode("utf-8")
    headers = {**_audiomuse_headers(), "Content-Type": "application/json"}
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        message = detail
        try:
            parsed = json.loads(detail)
            if isinstance(parsed, dict) and parsed.get("error"):
                message = str(parsed["error"])
        except json.JSONDecodeError:
            pass
        raise ChannelDesignerError(message or f"AudioMuse API HTTP {exc.code}", status=exc.code) from exc
    except urllib.error.URLError as exc:
        raise ChannelDesignerError(f"Could not reach AudioMuse API: {exc.reason}") from exc


# ---------------------------------------------------------------------------
# Channel programming model
# ---------------------------------------------------------------------------

PROGRAMMING_TYPES = (
    ("clap_query", "Sonic vibe (CLAP text search)"),
    ("lyrics_query", "Lyrics theme (semantic)"),
    ("mood_centroid", "Mood cluster"),
    ("alchemy_anchor", "Song Alchemy anchor"),
    ("similar_seed", "Similar to seed track"),
)

PROGRAMMING_TYPE_LABELS = {key: label for key, label in PROGRAMMING_TYPES}

REFRESH_MODES = (
    ("similar_to_last", "Similar to last played (recommended)"),
    ("similar_to_seed", "Similar to programming seed"),
    ("source_only", "Stay in source pool (allow repeats)"),
)

DIRECT_ALCHEMY_TYPES = frozenset({"alchemy_anchor", "similar_seed"})
PREVIEW_LIMIT_DEFAULT = 30
ANCHOR_BLEND_TRACKS = 8


def _slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or "channel"


def _normalize_mount(value: str) -> str:
    value = value.strip()
    return value if value.startswith("/") else f"/{value}"


def _track_rows_from_results(results: Any) -> list[dict[str, Any]]:
    if not isinstance(results, list):
        return []
    rows: list[dict[str, Any]] = []
    for row in results:
        if not isinstance(row, dict):
            continue
        item_id = row.get("item_id") or row.get("id")
        if not item_id:
            continue
        rows.append(
            {
                "item_id": str(item_id),
                "title": row.get("title") or "Unknown",
                "author": row.get("author") or row.get("artist") or "Unknown",
            }
        )
    return rows


def preview_programming(profile: dict[str, Any]) -> list[dict[str, Any]]:
    """Run AudioMuse intelligence APIs and return normalized track rows."""
    ptype = profile["programming"]["type"]
    limit = int(profile["programming"].get("limit") or PREVIEW_LIMIT_DEFAULT)
    limit = max(5, min(80, limit))

    if ptype == "clap_query":
        query = (profile["programming"].get("query") or "").strip()
        if len(query) < 3:
            raise ChannelDesignerError("CLAP query must be at least 3 characters.")
        data = audiomuse_post("/api/clap/search", {"query": query, "limit": limit})
        return _track_rows_from_results(data.get("results") if isinstance(data, dict) else None)

    if ptype == "lyrics_query":
        query = (profile["programming"].get("query") or "").strip()
        if len(query) < 3:
            raise ChannelDesignerError("Lyrics query must be at least 3 characters.")
        data = audiomuse_post("/api/lyrics/search/text", {"query": query, "limit": limit})
        return _track_rows_from_results(data.get("results") if isinstance(data, dict) else None)

    if ptype == "mood_centroid":
        mood = (profile["programming"].get("mood") or "").strip().lower()
        centroid_index = profile["programming"].get("centroid_index")
        if not mood or centroid_index is None:
            raise ChannelDesignerError("Choose a mood cluster.")
        data = audiomuse_get(
            "/api/similar_tracks",
            params={
                "mood": mood,
                "centroid_index": str(int(centroid_index)),
                "n": str(limit),
                "eliminate_duplicates": "true",
            },
        )
        return _track_rows_from_results(data)

    if ptype == "alchemy_anchor":
        anchor_id = str(profile["programming"].get("anchor_id") or "").strip()
        if not anchor_id:
            raise ChannelDesignerError("Choose a Song Alchemy anchor.")
        data = audiomuse_post(
            "/api/alchemy",
            {
                "items": [{"id": anchor_id, "op": "ADD", "type": "anchor"}],
                "n": limit,
            },
        )
        return _track_rows_from_results(data.get("results") if isinstance(data, dict) else None)

    if ptype == "similar_seed":
        item_id = str(profile["programming"].get("seed_id") or "").strip()
        if not item_id:
            raise ChannelDesignerError("Pick a seed track.")
        data = audiomuse_get(
            "/api/similar_tracks",
            params={"item_id": item_id, "n": str(limit), "eliminate_duplicates": "true"},
        )
        return _track_rows_from_results(data)

    raise ChannelDesignerError(f"Unsupported programming type: {ptype}")


def enrich_preview(tracks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ids = [t["item_id"] for t in tracks]
    if not ids:
        return tracks
    try:
        scores = {row["item_id"]: row for row in get_score_data_by_ids(ids)}
    except Exception:
        scores = {}
    enriched: list[dict[str, Any]] = []
    for track in tracks:
        row = dict(track)
        score = scores.get(track["item_id"]) or {}
        row["tempo"] = score.get("tempo")
        row["energy"] = score.get("energy")
        moods = score.get("mood_vector") or score.get("moods")
        if isinstance(moods, dict):
            top = sorted(moods.items(), key=lambda kv: kv[1], reverse=True)[:2]
            row["mood"] = ", ".join(name for name, _ in top)
        else:
            row["mood"] = ""
        enriched.append(row)
    return enriched


def _parse_optional_float(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _filters_from_form(form) -> dict[str, Any]:
    return {
        "tempo_min": _parse_optional_float(form.get("filter_tempo_min")),
        "tempo_max": _parse_optional_float(form.get("filter_tempo_max")),
        "energy_min": _parse_optional_float(form.get("filter_energy_min")),
        "energy_max": _parse_optional_float(form.get("filter_energy_max")),
    }


def _living_from_form(form) -> dict[str, Any]:
    return {
        "enabled": form.get("living_enabled") == "on",
        "auto_add_on_analyze": form.get("living_auto_add") == "on",
        "auto_refresh_alchemy": form.get("living_auto_refresh") == "on",
    }


def _filters_active(filters: dict[str, Any] | None) -> bool:
    if not filters:
        return False
    return any(filters.get(key) is not None for key in ("tempo_min", "tempo_max", "energy_min", "energy_max"))


def track_passes_filters(track: dict[str, Any], filters: dict[str, Any] | None) -> bool:
    if not _filters_active(filters):
        return True
    tempo = track.get("tempo")
    energy = track.get("energy")
    if tempo is None and energy is None:
        analysis = track.get("analysis") or {}
        tempo = analysis.get("tempo")
        energy = analysis.get("energy")
    if filters.get("tempo_min") is not None:
        if tempo is None or float(tempo) < float(filters["tempo_min"]):
            return False
    if filters.get("tempo_max") is not None:
        if tempo is None or float(tempo) > float(filters["tempo_max"]):
            return False
    if filters.get("energy_min") is not None:
        if energy is None or float(energy) < float(filters["energy_min"]):
            return False
    if filters.get("energy_max") is not None:
        if energy is None or float(energy) > float(filters["energy_max"]):
            return False
    return True


def apply_track_filters(tracks: list[dict[str, Any]], profile: dict[str, Any]) -> list[dict[str, Any]]:
    filters = profile.get("filters") or {}
    if not _filters_active(filters):
        return tracks
    return [track for track in tracks if track_passes_filters(track, filters)]


def _centroid_from_alchemy_response(data: Any) -> list[float] | None:
    if not isinstance(data, dict):
        return None
    for key in ("add_centroid_vector", "centroid"):
        vec = data.get(key)
        if isinstance(vec, list) and vec:
            return [float(x) for x in vec]
    return None


def _blend_centroid_from_tracks(tracks: list[dict[str, Any]], *, n_results: int = 50) -> list[float]:
    blend_ids = [t["item_id"] for t in tracks[:ANCHOR_BLEND_TRACKS]]
    if not blend_ids:
        raise ChannelDesignerError("No tracks to build an anchor from.")
    data = audiomuse_post(
        "/api/alchemy",
        {
            "items": [{"id": item_id, "op": "ADD", "type": "song"} for item_id in blend_ids],
            "n": n_results,
        },
    )
    centroid = _centroid_from_alchemy_response(data)
    if not centroid:
        raise ChannelDesignerError(
            "AudioMuse could not build an anchor centroid from the preview tracks. "
            "Ensure those tracks are analyzed (embeddings in the library) and try Preview again."
        )
    return centroid


def ensure_programming_anchor(profile: dict[str, Any], tracks: list[dict[str, Any]]) -> int:
    """Map AudioMuse-native programming to a Song Alchemy anchor Alchemy FM can run."""
    ptype = profile["programming"]["type"]
    existing = profile.get("anchor_id")
    if ptype == "alchemy_anchor":
        return int(profile["programming"]["anchor_id"])

    if existing:
        return int(existing)

    station_name = profile["station"]["name"]
    centroid = _blend_centroid_from_tracks(tracks)
    anchor_name = f"AFM: {station_name}"[:80]
    data = audiomuse_post("/api/anchors", {"name": anchor_name, "centroid": centroid})
    anchor = data.get("anchor") if isinstance(data, dict) else None
    if not isinstance(anchor, dict) or not anchor.get("id"):
        raise ChannelDesignerError("Failed to save Song Alchemy anchor for this channel.")
    return int(anchor["id"])


def channel_profile_to_alchemy_payload(profile: dict[str, Any], tracks: list[dict[str, Any]]) -> dict[str, Any]:
    station = profile["station"]
    refresh = profile.get("refresh") or {}
    ptype = profile["programming"]["type"]

    if ptype == "similar_seed":
        source_type = "similar_seed"
        source_ref = str(profile["programming"]["seed_id"]).strip()
        identity_anchor_id = ""
    else:
        anchor_id = ensure_programming_anchor(profile, tracks)
        profile["anchor_id"] = anchor_id
        source_type = "alchemy_anchor"
        source_ref = str(anchor_id)
        identity_anchor_id = str(anchor_id)

    return {
        "name": station["name"],
        "slug": station["slug"],
        "description": station.get("description", "")[:120],
        "icecast_mount": station["icecast_mount"],
        "enabled": bool(station.get("enabled", True)),
        "source_type": source_type,
        "source_ref": source_ref,
        "queue_target": int(station.get("queue_target", 30)),
        "refresh_threshold": int(station.get("refresh_threshold", 10)),
        "artist_separation_minutes": int(station.get("artist_separation_minutes", 90)),
        "continuation_mode": refresh.get("mode", "similar_to_last"),
        "identity_anchor_id": identity_anchor_id,
        "bootstrap_queue": bool(station.get("bootstrap_queue", True)),
        "designer_managed": True,
    }


def profile_from_form(form) -> dict[str, Any]:
    name = (form.get("name") or "").strip()
    if not name:
        raise ChannelDesignerError("Channel name is required.")

    ptype = (form.get("programming_type") or "clap_query").strip()
    editing_slug = (form.get("editing_slug") or "").strip()
    slug = editing_slug or (form.get("slug") or "").strip() or _slugify(name)
    refresh_mode = (form.get("refresh_mode") or "similar_to_last").strip()
    if refresh_mode not in {key for key, _ in REFRESH_MODES}:
        raise ChannelDesignerError(f"Unsupported refresh mode: {refresh_mode}")

    programming: dict[str, Any] = {"type": ptype, "limit": int(form.get("preview_limit") or PREVIEW_LIMIT_DEFAULT)}
    if ptype == "clap_query":
        programming["query"] = (form.get("clap_query") or "").strip()
    elif ptype == "lyrics_query":
        programming["query"] = (form.get("lyrics_query") or "").strip()
    elif ptype == "mood_centroid":
        programming["mood"] = (form.get("mood_name") or "").strip().lower()
        programming["centroid_index"] = form.get("centroid_index")
    elif ptype == "alchemy_anchor":
        programming["anchor_id"] = (form.get("anchor_id") or "").strip()
    elif ptype == "similar_seed":
        programming["seed_id"] = (
            (form.get("seed_id") or form.get("pick_seed") or "").strip()
        )
    else:
        raise ChannelDesignerError(f"Unsupported programming type: {ptype}")

    return {
        "programming": programming,
        "refresh": {"mode": refresh_mode},
        "filters": _filters_from_form(form),
        "living": _living_from_form(form),
        "station": {
            "name": name,
            "slug": slug,
            "description": (form.get("description") or "").strip(),
            "icecast_mount": _normalize_mount(form.get("icecast_mount") or slug),
            "enabled": form.get("enabled") == "on",
            "bootstrap_queue": form.get("bootstrap_queue") == "on",
            "queue_target": max(5, min(200, int(form.get("queue_target") or 30))),
            "refresh_threshold": max(1, min(100, int(form.get("refresh_threshold") or 10))),
            "artist_separation_minutes": max(0, int(form.get("artist_separation_minutes") or 90)),
        },
        "anchor_id": (form.get("saved_anchor_id") or "").strip() or None,
    }


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

bp = Blueprint("alchemy_fm_bridge", __name__)


def migrate(db) -> None:
    cur = db.cursor()
    channels = table("channels")
    cur.execute(
        "CREATE TABLE IF NOT EXISTS "
        + channels
        + " ("
        "id SERIAL PRIMARY KEY, "
        "name TEXT NOT NULL, "
        "slug TEXT NOT NULL UNIQUE, "
        "profile_json TEXT NOT NULL DEFAULT '{}', "
        "preview_ids_json TEXT NOT NULL DEFAULT '[]', "
        "anchor_id INTEGER, "
        "alchemy_station_id INTEGER, "
        "last_preview_at TEXT, "
        "last_pushed_at TEXT, "
        "last_action TEXT, "
        "last_error TEXT NOT NULL DEFAULT ''"
        ")"
    )
    pool = table("channel_pool")
    cur.execute(
        "CREATE TABLE IF NOT EXISTS "
        + pool
        + " ("
        "id SERIAL PRIMARY KEY, "
        "channel_slug TEXT NOT NULL, "
        "item_id TEXT NOT NULL, "
        "source TEXT NOT NULL DEFAULT 'preview', "
        "added_at TEXT, "
        "UNIQUE(channel_slug, item_id)"
        ")"
    )
    auditions = table("auditions")
    cur.execute(
        "CREATE TABLE IF NOT EXISTS "
        + auditions
        + " ("
        "id SERIAL PRIMARY KEY, "
        "channel_slug TEXT NOT NULL, "
        "run_at TEXT NOT NULL, "
        "track_count INTEGER NOT NULL DEFAULT 0, "
        "track_ids_json TEXT NOT NULL DEFAULT '[]'"
        ")"
    )
    cur.execute(
        "INSERT INTO cron (name, task_type, cron_expr, enabled) VALUES (%s, %s, %s, FALSE) "
        "ON CONFLICT (task_type) DO NOTHING",
        (
            f"plugin.{PLUGIN_ID}.refresh_living",
            f"plugin.{PLUGIN_ID}.refresh_living",
            "0 3 * * *",
        ),
    )
    # Legacy table from v1 — keep for upgrades
    profiles = table("profiles")
    cur.execute(
        "CREATE TABLE IF NOT EXISTS "
        + profiles
        + " ("
        "id SERIAL PRIMARY KEY, "
        "slug TEXT NOT NULL UNIQUE, "
        "alchemy_station_id INTEGER, "
        "config_json TEXT NOT NULL DEFAULT '{}', "
        "last_pushed_at TEXT, "
        "last_action TEXT, "
        "last_error TEXT NOT NULL DEFAULT ''"
        ")"
    )
    db.commit()
    cur.close()


def _client() -> AlchemyFmClient:
    base_url = (get_setting("alchemyfm_url") or "").strip()
    username = (get_setting("alchemyfm_username") or "admin").strip() or "admin"
    password = get_setting("alchemyfm_password") or ""
    if not base_url:
        raise ChannelDesignerError("Set your Alchemy FM URL in plugin settings first.")
    if not password:
        raise ChannelDesignerError("Set your Alchemy FM admin password in plugin settings first.")
    return AlchemyFmClient(base_url, username, password)


def _save_channel(
    profile: dict[str, Any],
    *,
    preview_ids: list[str],
    station: dict[str, Any] | None = None,
    action: str = "",
) -> None:
    db = get_db()
    cur = db.cursor()
    channels = table("channels")
    slug = profile["station"]["slug"]
    anchor_id = profile.get("anchor_id")
    pushed_at = "to_char(now(), 'YYYY-MM-DD HH24:MI:SS')" if action else "NULL"
    cur.execute(
        "INSERT INTO "
        + channels
        + " (name, slug, profile_json, preview_ids_json, anchor_id, alchemy_station_id, "
        "last_preview_at, last_pushed_at, last_action, last_error) "
        "VALUES (%s, %s, %s, %s, %s, %s, to_char(now(), 'YYYY-MM-DD HH24:MI:SS'), "
        + pushed_at
        + ", %s, '') "
        "ON CONFLICT (slug) DO UPDATE SET "
        "name = EXCLUDED.name, "
        "profile_json = EXCLUDED.profile_json, "
        "preview_ids_json = EXCLUDED.preview_ids_json, "
        "anchor_id = EXCLUDED.anchor_id, "
        "alchemy_station_id = COALESCE(EXCLUDED.alchemy_station_id, "
        + channels
        + ".alchemy_station_id), "
        "last_preview_at = EXCLUDED.last_preview_at, "
        "last_pushed_at = COALESCE(EXCLUDED.last_pushed_at, "
        + channels
        + ".last_pushed_at), "
        "last_action = CASE WHEN EXCLUDED.last_action <> '' THEN EXCLUDED.last_action ELSE "
        + channels
        + ".last_action END, "
        "last_error = ''",
        (
            profile["station"]["name"],
            slug,
            json.dumps(profile),
            json.dumps(preview_ids),
            int(anchor_id) if anchor_id else None,
            int(station.get("id")) if station else None,
            action,
        ),
    )
    db.commit()
    cur.close()


def _load_saved_channel(slug: str) -> tuple[dict[str, Any], list[str]] | None:
    slug = slug.strip()
    if not slug:
        return None
    db = get_db()
    cur = db.cursor()
    channels = table("channels")
    try:
        cur.execute(
            "SELECT profile_json, preview_ids_json FROM " + channels + " WHERE slug = %s",
            (slug,),
        )
        row = cur.fetchone()
    except Exception:
        db.rollback()
        return None
    finally:
        cur.close()
    if not row:
        return None
    try:
        profile = json.loads(row[0] or "{}")
        preview_ids = json.loads(row[1] or "[]")
        if not isinstance(preview_ids, list):
            preview_ids = []
    except json.JSONDecodeError:
        return None
    return profile, [str(i) for i in preview_ids if i]


def _preview_tracks_from_ids(item_ids: list[str]) -> list[dict[str, Any]]:
    if not item_ids:
        return []
    try:
        scores = get_score_data_by_ids(item_ids)
    except Exception:
        scores = []
    by_id = {row["item_id"]: row for row in scores if row.get("item_id")}
    tracks: list[dict[str, Any]] = []
    for item_id in item_ids:
        row = by_id.get(item_id) or {}
        tracks.append(
            {
                "item_id": item_id,
                "title": row.get("title") or "Unknown",
                "author": row.get("author") or row.get("artist") or "Unknown",
            }
        )
    return enrich_preview(tracks)


def _local_channels_by_slug() -> dict[str, tuple]:
    rows = _channel_rows()
    return {slug: row for row in rows for slug in [row[1]]}


def _delete_local_channel(slug: str) -> None:
    slug = slug.strip()
    if not slug:
        return
    db = get_db()
    cur = db.cursor()
    cur.execute("DELETE FROM " + table("channels") + " WHERE slug = %s", (slug,))
    db.commit()
    cur.close()


def _profile_from_remote_station(station: dict[str, Any]) -> dict[str, Any]:
    source_type = str(station.get("source_type") or "alchemy_anchor")
    source_ref = str(station.get("source_ref") or "")
    if source_type == "similar_seed":
        programming: dict[str, Any] = {
            "type": "similar_seed",
            "seed_id": source_ref,
            "limit": PREVIEW_LIMIT_DEFAULT,
        }
    else:
        programming = {
            "type": "alchemy_anchor",
            "anchor_id": source_ref,
            "limit": PREVIEW_LIMIT_DEFAULT,
        }
    continuation = str(station.get("continuation_mode") or "similar_to_last")
    anchor_id = station.get("identity_anchor_id") or (
        source_ref if source_type == "alchemy_anchor" else None
    )
    return {
        "programming": programming,
        "refresh": {"mode": continuation},
        "filters": {},
        "living": {"enabled": False, "auto_add_on_analyze": False, "auto_refresh_alchemy": False},
        "station": {
            "name": station.get("name") or "",
            "slug": station.get("slug") or "",
            "description": station.get("description") or "",
            "icecast_mount": station.get("icecast_mount") or f"/{station.get('slug', 'station')}",
            "enabled": bool(station.get("enabled", True)),
            "bootstrap_queue": False,
            "queue_target": int(station.get("queue_target") or 30),
            "refresh_threshold": int(station.get("refresh_threshold") or 10),
            "artist_separation_minutes": int(station.get("artist_separation_minutes") or 90),
        },
        "anchor_id": anchor_id,
    }


def _apply_loaded_channel(
    slug: str,
) -> tuple[dict[str, Any], list[dict[str, Any]], str]:
    slug = slug.strip()
    station_remote: dict[str, Any] | None = None
    try:
        station_remote = _client().find_station_by_slug(slug)
    except ChannelDesignerError:
        station_remote = None

    loaded = _load_saved_channel(slug)
    if loaded:
        profile, preview_ids = loaded
        values = _form_values_from_profile(profile)
        values["editing_slug"] = slug
        values["profile_source"] = "saved"
        preview_tracks = _preview_tracks_from_ids(preview_ids)
        channel_name = profile.get("station", {}).get("name") or slug
    elif station_remote:
        profile = _profile_from_remote_station(station_remote)
        values = _form_values_from_profile(profile)
        values["editing_slug"] = slug
        values["profile_source"] = "remote"
        preview_tracks = []
        channel_name = profile.get("station", {}).get("name") or slug
    else:
        raise ChannelDesignerError(f"No channel found locally or on Alchemy FM for slug '{slug}'.")

    if station_remote:
        values["edit_station_id"] = int(station_remote.get("id") or 0)
        values["edit_on_air"] = bool(station_remote.get("enabled"))
        values["edit_queued"] = station_remote.get("queued_count", station_remote.get("queued", "?"))
        values["edit_description"] = station_remote.get("description") or values.get("description", "")
    if (profile.get("living") or {}).get("enabled"):
        values["edit_pool_count"] = _pool_count(slug)
    return values, preview_tracks, channel_name


def _record_channel_error(slug: str, message: str) -> None:
    db = get_db()
    cur = db.cursor()
    channels = table("channels")
    cur.execute(
        "INSERT INTO " + channels + " (name, slug, profile_json, last_error) "
        "VALUES (%s, %s, '{}', %s) "
        "ON CONFLICT (slug) DO UPDATE SET last_error = EXCLUDED.last_error",
        (slug, slug, message[:500]),
    )
    db.commit()
    cur.close()


def _channel_rows() -> list[tuple]:
    db = get_db()
    cur = db.cursor()
    channels = table("channels")
    try:
        cur.execute(
            "SELECT name, slug, profile_json, anchor_id, alchemy_station_id, "
            "last_preview_at, last_pushed_at, last_action, last_error "
            "FROM " + channels + " ORDER BY last_pushed_at DESC NULLS LAST, slug ASC"
        )
        return cur.fetchall()
    except Exception:
        db.rollback()
        return []
    finally:
        cur.close()


def _record_audition(slug: str, item_ids: list[str]) -> None:
    slug = slug.strip()
    if not slug:
        return
    db = get_db()
    cur = db.cursor()
    auditions = table("auditions")
    cur.execute(
        "INSERT INTO "
        + auditions
        + " (channel_slug, run_at, track_count, track_ids_json) "
        "VALUES (%s, to_char(now(), 'YYYY-MM-DD HH24:MI:SS'), %s, %s)",
        (slug, len(item_ids), json.dumps(item_ids)),
    )
    cur.execute(
        "DELETE FROM "
        + auditions
        + " WHERE id NOT IN ("
        "SELECT id FROM "
        + auditions
        + " WHERE channel_slug = %s ORDER BY id DESC LIMIT 20"
        ")",
        (slug,),
    )
    db.commit()
    cur.close()


def _add_to_pool(slug: str, item_ids: list[str], *, source: str = "preview") -> int:
    slug = slug.strip()
    if not slug or not item_ids:
        return 0
    db = get_db()
    cur = db.cursor()
    pool = table("channel_pool")
    added = 0
    for item_id in item_ids:
        cur.execute(
            "INSERT INTO "
            + pool
            + " (channel_slug, item_id, source, added_at) "
            "VALUES (%s, %s, %s, to_char(now(), 'YYYY-MM-DD HH24:MI:SS')) "
            "ON CONFLICT (channel_slug, item_id) DO NOTHING",
            (slug, str(item_id), source),
        )
        if cur.rowcount:
            added += 1
    db.commit()
    cur.close()
    return added


def _pool_item_ids(slug: str, *, limit: int = 200) -> list[str]:
    slug = slug.strip()
    if not slug:
        return []
    db = get_db()
    cur = db.cursor()
    pool = table("channel_pool")
    try:
        cur.execute(
            "SELECT item_id FROM "
            + pool
            + " WHERE channel_slug = %s ORDER BY added_at DESC NULLS LAST, id DESC LIMIT %s",
            (slug, int(limit)),
        )
        return [str(row[0]) for row in cur.fetchall() if row and row[0]]
    except Exception:
        db.rollback()
        return []
    finally:
        cur.close()


def _pool_count(slug: str) -> int:
    slug = slug.strip()
    if not slug:
        return 0
    db = get_db()
    cur = db.cursor()
    try:
        cur.execute(
            "SELECT COUNT(*) FROM " + table("channel_pool") + " WHERE channel_slug = %s",
            (slug,),
        )
        row = cur.fetchone()
        return int(row[0]) if row else 0
    except Exception:
        db.rollback()
        return 0
    finally:
        cur.close()


def _living_channel_profiles() -> list[tuple[str, dict[str, Any], int | None]]:
    rows = _channel_rows()
    living: list[tuple[str, dict[str, Any], int | None]] = []
    for row in rows:
        slug = str(row[1] or "")
        try:
            profile = json.loads(row[2] or "{}")
        except json.JSONDecodeError:
            continue
        living_cfg = profile.get("living") or {}
        if not living_cfg.get("enabled"):
            continue
        alchemy_id = row[4]
        living.append((slug, profile, int(alchemy_id) if alchemy_id else None))
    return living


def _audition_rows(slug: str | None = None, *, limit: int = 10) -> list[tuple]:
    db = get_db()
    cur = db.cursor()
    auditions = table("auditions")
    try:
        if slug:
            cur.execute(
                "SELECT channel_slug, run_at, track_count, track_ids_json FROM "
                + auditions
                + " WHERE channel_slug = %s ORDER BY id DESC LIMIT %s",
                (slug.strip(), int(limit)),
            )
        else:
            cur.execute(
                "SELECT channel_slug, run_at, track_count, track_ids_json FROM "
                + auditions
                + " ORDER BY id DESC LIMIT %s",
                (int(limit),),
            )
        return cur.fetchall()
    except Exception:
        db.rollback()
        return []
    finally:
        cur.close()


def on_song_analyzed(song: dict[str, Any]) -> None:
    item_id = str(song.get("item_id") or "").strip()
    if not item_id:
        return
    analysis = song.get("analysis") or {}
    track = {
        "item_id": item_id,
        "tempo": analysis.get("tempo"),
        "energy": analysis.get("energy"),
    }
    for slug, profile, _alchemy_id in _living_channel_profiles():
        living_cfg = profile.get("living") or {}
        if not living_cfg.get("auto_add_on_analyze"):
            continue
        if not track_passes_filters(track, profile.get("filters")):
            continue
        added = _add_to_pool(slug, [item_id], source="analyze")
        if added:
            logger.info(
                "alchemy_fm_bridge living pool +1 slug=%s item_id=%s",
                slug,
                item_id,
            )


def refresh_living_channels() -> None:
    channels = _living_channel_profiles()
    if not channels:
        logger.info("alchemy_fm_bridge refresh_living: no living channels configured")
        return

    client: AlchemyFmClient | None = None
    for slug, profile, alchemy_station_id in channels:
        try:
            raw = preview_programming(profile)
            filtered = apply_track_filters(enrich_preview(raw), profile)
            item_ids = [t["item_id"] for t in filtered]
            if not item_ids:
                logger.warning("alchemy_fm_bridge refresh_living: no tracks for slug=%s", slug)
                continue

            _record_audition(slug, item_ids)
            added = _add_to_pool(slug, item_ids, source="cron")
            _save_channel(profile, preview_ids=item_ids)

            living_cfg = profile.get("living") or {}
            if not living_cfg.get("auto_refresh_alchemy") or not alchemy_station_id:
                logger.info(
                    "alchemy_fm_bridge refresh_living slug=%s pool=%s added=%s",
                    slug,
                    len(item_ids),
                    added,
                )
                continue

            payload = channel_profile_to_alchemy_payload(profile, filtered or raw)
            if client is None:
                try:
                    client = _client()
                except ChannelDesignerError as exc:
                    logger.warning("alchemy_fm_bridge refresh_living: Alchemy FM unavailable: %s", exc)
                    continue

            update_fields = {
                key: value
                for key, value in payload.items()
                if key not in ("slug", "bootstrap_queue")
            }
            client.update_station(int(alchemy_station_id), update_fields)
            client.refresh_queue(int(alchemy_station_id))
            logger.info(
                "alchemy_fm_bridge refresh_living slug=%s updated station=%s pool=%s",
                slug,
                alchemy_station_id,
                _pool_count(slug),
            )
        except ChannelDesignerError as exc:
            _record_channel_error(slug, str(exc))
            logger.warning("alchemy_fm_bridge refresh_living slug=%s failed: %s", slug, exc)
        except Exception:
            logger.exception("alchemy_fm_bridge refresh_living slug=%s failed", slug)


# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------


def _flash_html(message: str, level: str = "ok") -> str:
    level_class = "afm-flash-ok" if level == "ok" else "afm-flash-error"
    return f'<p class="afm-flash {level_class}">{html.escape(message)}</p>'


def _page_styles() -> str:
    return """
<style>
.afm-shell { max-width: 58rem; margin: 0 auto; }
.afm-lede { color: var(--muted, #64748b); margin: 0 0 1.25rem; line-height: 1.55; }
.afm-flash { padding: 0.75rem 1rem; border-radius: 10px; margin: 0 0 1rem; }
.afm-flash-ok { background: #ecfdf5; border: 1px solid #6ee7b7; color: #065f46; }
.afm-flash-error { background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; }
.afm-section { margin: 0 0 1.75rem; }
.afm-section-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 1rem; margin-bottom: 0.85rem; flex-wrap: wrap; }
.afm-section-title { margin: 0; font-size: 1.15rem; }
.afm-section-note { margin: 0.15rem 0 0; color: var(--muted, #64748b); font-size: 0.92rem; }
.afm-station-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 0.85rem; }
.afm-station-card { border: 1px solid #dbe3ef; border-radius: 12px; padding: 0.95rem 1rem; background: #fff; display: grid; gap: 0.65rem; box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04); }
.afm-station-card.is-editing { border-color: #2563eb; box-shadow: 0 0 0 1px #2563eb, 0 8px 24px rgba(37, 99, 235, 0.12); }
.afm-station-card-head { display: flex; justify-content: space-between; gap: 0.75rem; align-items: flex-start; }
.afm-station-name { margin: 0; font-size: 1rem; line-height: 1.3; }
.afm-station-slug { color: var(--muted, #64748b); font-size: 0.84rem; margin-top: 0.15rem; }
.afm-station-programming { margin: 0; font-size: 0.9rem; line-height: 1.45; color: #334155; }
.afm-station-programming strong { display: block; font-size: 0.78rem; letter-spacing: 0.04em; text-transform: uppercase; color: #64748b; margin-bottom: 0.15rem; }
.afm-station-stats { display: flex; flex-wrap: wrap; gap: 0.4rem; }
.afm-station-actions { display: flex; gap: 0.5rem; flex-wrap: wrap; margin-top: 0.15rem; }
.afm-badge { display: inline-flex; align-items: center; padding: 0.15rem 0.55rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; line-height: 1.4; }
.afm-badge-live { background: #dcfce7; color: #166534; }
.afm-badge-off { background: #f1f5f9; color: #475569; }
.afm-badge-queue { background: #eff6ff; color: #1d4ed8; }
.afm-badge-saved { background: #f5f3ff; color: #6d28d9; }
.afm-badge-remote { background: #fff7ed; color: #c2410c; }
.afm-badge-living { background: #ecfeff; color: #0e7490; }
.afm-btn { display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem; padding: 0.48rem 0.85rem; border-radius: 8px; border: 1px solid #cbd5e1; background: #fff; color: #0f172a; font: inherit; cursor: pointer; text-decoration: none; line-height: 1.2; }
.afm-btn:hover { background: #f8fafc; }
.afm-btn-primary { background: #2563eb; border-color: #2563eb; color: #fff; }
.afm-btn-primary:hover { background: #1d4ed8; }
.afm-btn-secondary { background: #f8fafc; }
.afm-btn-danger { background: #fff; border-color: #fecaca; color: #b91c1c; }
.afm-btn-danger:hover { background: #fef2f2; }
.afm-edit-bar { display: flex; justify-content: space-between; gap: 1rem; align-items: flex-start; flex-wrap: wrap; padding: 1rem 1.1rem; margin: 0 0 1rem; border: 1px solid #bfdbfe; border-radius: 14px; background: linear-gradient(180deg, #eff6ff 0%, #f8fbff 100%); }
.afm-edit-eyebrow { display: block; font-size: 0.78rem; letter-spacing: 0.08em; text-transform: uppercase; color: #2563eb; margin-bottom: 0.2rem; }
.afm-edit-title { margin: 0; font-size: 1.35rem; line-height: 1.2; }
.afm-edit-meta { display: flex; flex-wrap: wrap; gap: 0.45rem; margin-top: 0.55rem; align-items: center; }
.afm-edit-slug { color: #475569; font-size: 0.9rem; }
.afm-edit-actions { display: flex; gap: 0.55rem; flex-wrap: wrap; align-items: center; }
.afm-designer-panel { border: 1px solid #dbe3ef; border-radius: 14px; padding: 1rem; background: #fff; }
.afm-designer-panel + .afm-designer-panel { margin-top: 0.85rem; }
.afm-designer-panel legend { font-size: 0.98rem; padding: 0 0.35rem; }
.afm-designer-panel label { display: block; font-weight: 600; margin-bottom: 0.25rem; }
.afm-designer-panel input[type="text"], .afm-designer-panel input[type="number"], .afm-designer-panel input[type="password"], .afm-designer-panel textarea, .afm-designer-panel select { width: 100%; max-width: 100%; box-sizing: border-box; }
.afm-form-actions { display: flex; gap: 0.65rem; flex-wrap: wrap; margin-top: 0.35rem; }
.afm-empty { color: var(--muted, #64748b); margin: 0; }
.afm-designer-panel input.is-readonly { opacity: 0.75; }
@media (max-width: 720px) {
  .afm-station-grid { grid-template-columns: 1fr; }
  .afm-edit-bar { padding: 0.9rem; }
  .afm-edit-actions { width: 100%; }
  .afm-edit-actions .afm-btn { flex: 1 1 auto; }
}
</style>
"""


def _select_options(options: list[tuple[str, str]], selected: str) -> str:
    return "".join(
        f'<option value="{html.escape(key)}"{" selected" if key == selected else ""}>'
        f"{html.escape(label)}</option>"
        for key, label in options
    )


def _anchors() -> list[dict[str, Any]]:
    try:
        data = audiomuse_get("/api/anchors")
    except ChannelDesignerError:
        return []
    anchors = data.get("anchors") if isinstance(data, dict) else None
    return [a for a in anchors if isinstance(a, dict) and a.get("id")] if isinstance(anchors, list) else []


def _mood_centroids_data() -> dict[str, Any]:
    try:
        data = audiomuse_get("/api/mood_centroids")
        return data if isinstance(data, dict) else {}
    except ChannelDesignerError:
        return {}


def _mood_cluster_label(meta: dict[str, Any], idx: int) -> str:
    index = meta.get("index", idx)
    label = f"Cluster {index}"
    tags = meta.get("top_tags") or meta.get("tags") or meta.get("label")
    if isinstance(tags, list) and tags:
        label = ", ".join(str(t) for t in tags[:3])
        n_songs = meta.get("n_songs")
        if n_songs:
            label += f" ({n_songs} tracks)"
    elif isinstance(tags, str) and tags:
        label = tags
    return label


def _mood_options(selected_mood: str, selected_index: str) -> tuple[str, str]:
    data = _mood_centroids_data()
    if not data:
        return (
            "<option value=''>Could not load moods</option>",
            "<option value=''>—</option>",
        )

    mood_opts = ['<option value="">Choose mood…</option>']
    for mood in sorted(data.keys()):
        sel = " selected" if mood == selected_mood else ""
        mood_opts.append(f'<option value="{html.escape(mood)}"{sel}>{html.escape(mood.title())}</option>')

    centroid_opts = ['<option value="">Choose cluster…</option>']
    if selected_mood and selected_mood in data:
        centroids = data[selected_mood]
        if isinstance(centroids, list):
            for idx, meta in enumerate(centroids):
                if not isinstance(meta, dict):
                    continue
                cluster_idx = meta.get("index", idx)
                label = _mood_cluster_label(meta, idx)
                sel = " selected" if str(cluster_idx) == str(selected_index) else ""
                centroid_opts.append(
                    f'<option value="{cluster_idx}"{sel}>{html.escape(label)}</option>'
                )
    return ("".join(mood_opts), "".join(centroid_opts))


def _search_tracks(query: str) -> list[dict[str, Any]]:
    query = query.strip()
    if len(query) < 2:
        return []
    try:
        data = audiomuse_get(
            "/api/search_tracks",
            params={"search_query": query, "end": "20"},
        )
    except ChannelDesignerError:
        return []
    return [t for t in data if isinstance(t, dict) and t.get("item_id")] if isinstance(data, list) else []


def _preview_table_html(tracks: list[dict[str, Any]]) -> str:
    if not tracks:
        return "<p class='hint'>No tracks matched this programming yet. Run a preview.</p>"
    rows = []
    for track in tracks:
        tempo = track.get("tempo")
        energy = track.get("energy")
        tempo_s = f"{float(tempo):.0f}" if tempo is not None else "—"
        energy_s = f"{float(energy):.2f}" if energy is not None else "—"
        rows.append(
            "<tr>"
            f"<td style='padding:0.4rem 0.6rem;border-bottom:1px solid #eee;'>{html.escape(track['title'])}</td>"
            f"<td style='padding:0.4rem 0.6rem;border-bottom:1px solid #eee;'>{html.escape(track['author'])}</td>"
            f"<td style='padding:0.4rem 0.6rem;border-bottom:1px solid #eee;'>{tempo_s}</td>"
            f"<td style='padding:0.4rem 0.6rem;border-bottom:1px solid #eee;'>{energy_s}</td>"
            f"<td style='padding:0.4rem 0.6rem;border-bottom:1px solid #eee;'>{html.escape(track.get('mood') or '—')}</td>"
            "</tr>"
        )
    return (
        f"<p><strong>{len(tracks)}</strong> tracks in preview (from your AudioMuse library analysis).</p>"
        "<table style='width:100%;border-collapse:collapse;font-size:0.92rem;'>"
        "<thead><tr>"
        "<th style='text-align:left;padding:0.4rem 0.6rem;border-bottom:1px solid #ccc;'>Title</th>"
        "<th style='text-align:left;padding:0.4rem 0.6rem;border-bottom:1px solid #ccc;'>Artist</th>"
        "<th style='text-align:left;padding:0.4rem 0.6rem;border-bottom:1px solid #ccc;'>BPM</th>"
        "<th style='text-align:left;padding:0.4rem 0.6rem;border-bottom:1px solid #ccc;'>Energy</th>"
        "<th style='text-align:left;padding:0.4rem 0.6rem;border-bottom:1px solid #ccc;'>Mood</th>"
        "</tr></thead><tbody>"
        + "".join(rows)
        + "</tbody></table>"
    )


def _programming_fields_html(values: dict[str, Any]) -> str:
    ptype = values.get("programming_type", "clap_query")
    hidden = lambda key: "" if ptype == key else " hidden"

    mood_opts, centroid_opts = _mood_options(
        str(values.get("mood_name", "")),
        str(values.get("centroid_index", "")),
    )

    seed_results = values.get("seed_search_results") or []
    seed_results_html = ""
    if seed_results:
        items = []
        for track in seed_results:
            item_id = str(track.get("item_id"))
            title = track.get("title") or "Unknown"
            artist = track.get("author") or track.get("artist") or "Unknown"
            items.append(
                "<li>"
                f'<button type="submit" name="pick_seed" value="{html.escape(item_id)}" '
                'formnovalidate style="width:100%;text-align:left;padding:0.5rem;">'
                f"{html.escape(title)} — {html.escape(artist)}"
                "</button></li>"
            )
        seed_results_html = "<ul style='list-style:none;padding:0;margin:0.5rem 0;'>" + "".join(items) + "</ul>"

    anchor_opts = ['<option value="">Choose anchor…</option>']
    for anchor in _anchors():
        aid = str(anchor["id"])
        sel = " selected" if aid == str(values.get("anchor_id", "")) else ""
        anchor_opts.append(
            f'<option value="{html.escape(aid)}"{sel}>{html.escape(anchor.get("name") or aid)}</option>'
        )

    return (
        "<fieldset class='afm-designer-panel'>"
        "<legend><strong>Programming</strong> — how AudioMuse finds tracks</legend>"
        "<div><label>Programming type</label>"
        f"<select name='programming_type' id='programming_type'>"
        f"{_select_options(PROGRAMMING_TYPES, ptype)}</select></div>"
        f"<div id='field-clap'{hidden('clap_query')} style='margin-top:0.75rem;'>"
        "<label>Sonic vibe (describe the sound)</label>"
        f"<input name='clap_query' style='width:100%;' placeholder='e.g. late-night yacht rock, warm and mellow' "
        f"value='{html.escape(str(values.get('clap_query', '')))}'>"
        "<p class='hint'>Uses CLAP text-to-audio search across your analyzed library.</p></div>"
        f"<div id='field-lyrics'{hidden('lyrics_query')} style='margin-top:0.75rem;'>"
        "<label>Lyrics theme</label>"
        f"<input name='lyrics_query' style='width:100%;' placeholder='e.g. songs about the open road' "
        f"value='{html.escape(str(values.get('lyrics_query', '')))}'>"
        "<p class='hint'>Semantic lyrics search — meaning and themes, not just keywords.</p></div>"
        f"<div id='field-mood'{hidden('mood_centroid')} style='margin-top:0.75rem;display:grid;gap:0.5rem;'>"
        "<div><label>Mood</label><select name='mood_name'>" + mood_opts + "</select></div>"
        "<div><label>Cluster</label><select name='centroid_index' id='centroid_index'>" + centroid_opts + "</select></div>"
        "<p class='hint'>Each mood has sub-clusters from your library analysis — pick one that matches "
        "the vibe (tags show the dominant traits in that cluster).</p></div>"
        f"<div id='field-anchor'{hidden('alchemy_anchor')} style='margin-top:0.75rem;'>"
        "<label>Song Alchemy anchor</label>"
        f"<select name='anchor_id'>{''.join(anchor_opts)}</select></div>"
        f"<div id='field-seed'{hidden('similar_seed')} style='margin-top:0.75rem;'>"
        "<label>Search seed track</label>"
        f"<input name='seed_search' value='{html.escape(str(values.get('seed_search', '')))}'> "
        "<button type='submit' name='action' value='search_seed' formnovalidate>Search</button>"
        f"{seed_results_html}"
        f"<input name='seed_id' placeholder='Track item id' value='{html.escape(str(values.get('seed_id', '')))}'>"
        "</div>"
        "<div style='margin-top:0.75rem;'>"
        "<label>Preview size</label> "
        f"<input type='number' name='preview_limit' min='10' max='80' value='{html.escape(str(values.get('preview_limit', PREVIEW_LIMIT_DEFAULT)))}'>"
        "</div></fieldset>"
    )


def _filters_fields_html(values: dict[str, Any]) -> str:
    return (
        "<fieldset class='afm-designer-panel'>"
        "<legend><strong>Filters</strong> — narrow preview and living pool by analysis</legend>"
        "<p class='hint'>Optional tempo and energy bounds apply to preview results and to songs "
        "auto-added when living channels are enabled.</p>"
        "<div style='display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0.75rem;'>"
        "<div><label>Tempo min (BPM)</label>"
        f"<input type='number' name='filter_tempo_min' min='0' step='1' "
        f"value='{html.escape(str(values.get('filter_tempo_min', '')))}' placeholder='any'></div>"
        "<div><label>Tempo max (BPM)</label>"
        f"<input type='number' name='filter_tempo_max' min='0' step='1' "
        f"value='{html.escape(str(values.get('filter_tempo_max', '')))}' placeholder='any'></div>"
        "<div><label>Energy min (0–1)</label>"
        f"<input type='number' name='filter_energy_min' min='0' max='1' step='0.01' "
        f"value='{html.escape(str(values.get('filter_energy_min', '')))}' placeholder='any'></div>"
        "<div><label>Energy max (0–1)</label>"
        f"<input type='number' name='filter_energy_max' min='0' max='1' step='0.01' "
        f"value='{html.escape(str(values.get('filter_energy_max', '')))}' placeholder='any'></div>"
        "</div></fieldset>"
    )


def _living_fields_html(values: dict[str, Any]) -> str:
    slug = (values.get("editing_slug") or values.get("slug") or "").strip()
    pool_note = ""
    if slug:
        pool_note = (
            f"<p class='hint'>Pool for <strong>{html.escape(slug)}</strong>: "
            f"{_pool_count(slug)} track(s) tracked for evolution.</p>"
        )
    living_enabled = values.get("living_enabled", False)
    auto_add = values.get("living_auto_add", living_enabled)
    auto_refresh = values.get("living_auto_refresh", living_enabled)
    return (
        "<fieldset class='afm-designer-panel'>"
        "<legend><strong>Living channel</strong> — evolve as your library grows</legend>"
        "<p class='hint'>When enabled, newly analyzed songs that pass filters can join the channel pool. "
        "The nightly cron task re-runs programming, refreshes the pool, and optionally updates Alchemy FM.</p>"
        f"{pool_note}"
        "<label><input type='checkbox' name='living_enabled'"
        f"{' checked' if living_enabled else ''}> Enable living channel</label><br>"
        "<label><input type='checkbox' name='living_auto_add'"
        f"{' checked' if auto_add else ''}> Auto-add new analyzed songs that pass filters</label><br>"
        "<label><input type='checkbox' name='living_auto_refresh'"
        f"{' checked' if auto_refresh else ''}> Nightly refresh: re-score pool and push to Alchemy FM</label>"
        "<p class='hint'>Enable the <code>plugin.alchemy_fm_bridge.refresh_living</code> schedule under "
        "Administration → Scheduled Tasks (default: 03:00 daily, disabled until you turn it on).</p>"
        "</fieldset>"
    )


def _audition_history_html(slug: str | None = None) -> str:
    rows = _audition_rows(slug, limit=12)
    if not rows:
        hint = "Run a preview to record audition history."
        if slug:
            hint = f"No auditions recorded for {slug} yet. Preview programming to start."
        return f"<p class='hint'>{html.escape(hint)}</p>"

    body = (
        "<table style='width:100%;border-collapse:collapse;font-size:0.92rem;margin-top:0.5rem;'>"
        "<thead><tr>"
        "<th style='text-align:left;padding:0.4rem 0.6rem;border-bottom:1px solid #ccc;'>When</th>"
        "<th style='text-align:left;padding:0.4rem 0.6rem;border-bottom:1px solid #ccc;'>Channel</th>"
        "<th style='text-align:left;padding:0.4rem 0.6rem;border-bottom:1px solid #ccc;'>Tracks</th>"
        "</tr></thead><tbody>"
    )
    for channel_slug, run_at, track_count, _track_ids_json in rows:
        body += (
            "<tr>"
            f"<td style='padding:0.4rem 0.6rem;border-bottom:1px solid #eee;'>{html.escape(str(run_at))}</td>"
            f"<td style='padding:0.4rem 0.6rem;border-bottom:1px solid #eee;'>{html.escape(str(channel_slug))}</td>"
            f"<td style='padding:0.4rem 0.6rem;border-bottom:1px solid #eee;'>{int(track_count)}</td>"
            "</tr>"
        )
    return body + "</tbody></table>"


def _deploy_fields_html(values: dict[str, Any]) -> str:
    editing_slug = (values.get("editing_slug") or "").strip()
    slug_readonly = " readonly class='is-readonly'" if editing_slug else ""
    slug_extra = ""
    if editing_slug:
        slug_extra = (
            f"<input type='hidden' name='editing_slug' value='{html.escape(editing_slug)}'>"
            "<p class='hint'>Slug is fixed after first deploy (Alchemy FM identifies stations by slug).</p>"
        )
    deploy_label = "Save changes to Alchemy FM" if editing_slug else "Deploy to Alchemy FM"
    step_label = "Broadcast settings" if editing_slug else "2. Channel + deploy"
    return (
        "<fieldset class='afm-designer-panel'>"
        f"<legend><strong>{html.escape(step_label)}</strong> — station on Alchemy FM</legend>"
        "<div style='display:grid;gap:0.75rem;'>"
        "<div><label>Channel name</label>"
        f"<input name='name' required value='{html.escape(str(values.get('name', '')))}'></div>"
        "<div><label>Slug</label>"
        f"<input name='slug' placeholder='auto from name' "
        f"value='{html.escape(str(values.get('slug', editing_slug or '')))}'{slug_readonly}>"
        f"{slug_extra}</div>"
        "<div><label>Description</label>"
        f"<textarea name='description' maxlength='120' rows='2'>{html.escape(str(values.get('description', '')))}</textarea></div>"
        "<div><label>Icecast mount</label>"
        f"<input name='icecast_mount' placeholder='/channel-slug' value='{html.escape(str(values.get('icecast_mount', '')))}'></div>"
        "<div><label>When pool runs low</label>"
        f"<select name='refresh_mode'>{_select_options(REFRESH_MODES, str(values.get('refresh_mode', 'similar_to_last')))}</select>"
        "<p class='hint'>For CLAP/lyrics/mood channels, the plugin saves a Song Alchemy anchor from your preview "
        "so Alchemy FM can keep refilling 24/7.</p></div>"
        "<div style='display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0.75rem;'>"
        "<div><label>Queue target</label>"
        f"<input type='number' name='queue_target' min='5' max='200' value='{html.escape(str(values.get('queue_target', 30)))}'></div>"
        "<div><label>Refresh below</label>"
        f"<input type='number' name='refresh_threshold' min='1' max='100' value='{html.escape(str(values.get('refresh_threshold', 10)))}'></div>"
        "<div><label>Artist separation (min)</label>"
        f"<input type='number' name='artist_separation_minutes' min='0' value='{html.escape(str(values.get('artist_separation_minutes', 90)))}'></div>"
        "</div>"
        "<label><input type='checkbox' name='enabled'"
        f"{' checked' if values.get('enabled', True) else ''}> Start on air after push</label> "
        "<label><input type='checkbox' name='bootstrap_queue'"
        f"{' checked' if values.get('bootstrap_queue', True) else ''}> Bootstrap queue immediately</label>"
        f"<input type='hidden' name='saved_anchor_id' value='{html.escape(str(values.get('saved_anchor_id', '')))}'>"
        "<div class='afm-form-actions'>"
        f"<button type='submit' name='action' value='push' class='afm-btn afm-btn-primary'>{html.escape(deploy_label)}</button>"
        "<button type='submit' name='action' value='preview' class='afm-btn afm-btn-secondary'>Preview programming</button>"
        "<button type='submit' name='action' value='test' formnovalidate class='afm-btn afm-btn-secondary'>Test connection</button>"
        "</div></div></fieldset>"
    )


def _programming_detail(profile: dict[str, Any] | None, station: dict[str, Any]) -> tuple[str, str, bool, bool]:
    has_saved = profile is not None
    living = bool((profile or {}).get("living", {}).get("enabled"))
    if profile:
        programming = profile.get("programming") or {}
        ptype = programming.get("type", "?")
        type_label = PROGRAMMING_TYPE_LABELS.get(ptype, ptype.replace("_", " ").title())
        detail = (
            programming.get("query")
            or programming.get("seed_id")
            or programming.get("anchor_id")
            or programming.get("mood")
            or ""
        )
        if ptype == "mood_centroid":
            mood = programming.get("mood") or ""
            cluster = programming.get("centroid_index")
            detail = f"{mood} · cluster {cluster}" if cluster is not None else mood
        return type_label, str(detail)[:96], living, has_saved
    source_type = str(station.get("source_type") or "?")
    source_ref = str(station.get("source_ref") or "")
    type_label = PROGRAMMING_TYPE_LABELS.get(source_type, source_type.replace("_", " ").title())
    return type_label, source_ref[:96], False, False


def _programming_label(profile: dict[str, Any] | None, station: dict[str, Any]) -> str:
    type_label, detail, _, _ = _programming_detail(profile, station)
    return f"{type_label}: {detail}"[:72]


def _edit_toolbar_html(values: dict[str, Any]) -> str:
    editing_slug = (values.get("editing_slug") or "").strip()
    if not editing_slug:
        return ""
    name = (values.get("name") or editing_slug).strip()
    source = values.get("profile_source") or "remote"
    source_badge = (
        '<span class="afm-badge afm-badge-saved">Saved design</span>'
        if source == "saved"
        else '<span class="afm-badge afm-badge-remote">Alchemy FM only</span>'
    )
    on_air_badge = (
        '<span class="afm-badge afm-badge-live">On air</span>'
        if values.get("edit_on_air")
        else '<span class="afm-badge afm-badge-off">Off air</span>'
    )
    queued = values.get("edit_queued", "?")
    extra_badges = ""
    if values.get("living_enabled") or values.get("edit_pool_count"):
        pool_count = values.get("edit_pool_count", _pool_count(editing_slug))
        extra_badges = f'<span class="afm-badge afm-badge-living">Living · {pool_count} in pool</span>'
    station_id = values.get("edit_station_id")
    id_note = f" · id {station_id}" if station_id else ""
    return (
        f'<div class="afm-edit-bar" id="designer">'
        "<div>"
        '<span class="afm-edit-eyebrow">Editing station</span>'
        f'<h2 class="afm-edit-title">{html.escape(name)}</h2>'
        '<div class="afm-edit-meta">'
        f'<span class="afm-edit-slug">{html.escape(editing_slug)}{html.escape(id_note)}</span>'
        f"{source_badge}{on_air_badge}"
        f'<span class="afm-badge afm-badge-queue">{html.escape(str(queued))} queued</span>'
        f"{extra_badges}"
        "</div>"
        "</div>"
        '<div class="afm-edit-actions">'
        f'<a href="{html.escape(url_for("alchemy_fm_bridge.home"))}" class="afm-btn afm-btn-secondary">← All stations</a>'
        '<button type="submit" form="afm-designer-form" name="action" value="new_channel" formnovalidate '
        'class="afm-btn afm-btn-secondary">New channel</button>'
        '<button type="submit" form="afm-designer-form" name="action" value="push" '
        'class="afm-btn afm-btn-primary">Save changes</button>'
        "</div></div>"
    )


def _stations_section_html(editing_slug: str | None = None) -> str:
    try:
        stations = _client().test_connection()
    except ChannelDesignerError as exc:
        return (
            '<section class="afm-section">'
            f'<p class="afm-empty">Could not load Alchemy FM stations: {html.escape(str(exc))}</p>'
            "</section>"
        )

    editing_slug = (editing_slug or "").strip().lower()
    local = _local_channels_by_slug()
    if not stations:
        cards = '<p class="afm-empty">No stations yet. Use the designer below to create your first channel.</p>'
    else:
        cards = ['<div class="afm-station-grid">']
        for station in sorted(stations, key=lambda s: str(s.get("name") or s.get("slug") or "")):
            slug = str(station.get("slug") or "")
            slug_key = slug.lower()
            name = str(station.get("name") or slug or "Station")
            station_id = int(station.get("id") or 0)
            queued = str(station.get("queued_count", station.get("queued", "?")))
            profile = None
            if slug in local:
                try:
                    profile = json.loads(local[slug][2] or "{}")
                except json.JSONDecodeError:
                    profile = None
            type_label, detail, living, has_saved = _programming_detail(profile, station)
            is_editing = slug_key == editing_slug
            card_class = "afm-station-card is-editing" if is_editing else "afm-station-card"
            on_air_badge = (
                '<span class="afm-badge afm-badge-live">On air</span>'
                if station.get("enabled")
                else '<span class="afm-badge afm-badge-off">Off air</span>'
            )
            profile_badge = (
                '<span class="afm-badge afm-badge-saved">Saved design</span>'
                if has_saved
                else '<span class="afm-badge afm-badge-remote">Remote only</span>'
            )
            living_badge = '<span class="afm-badge afm-badge-living">Living</span>' if living else ""
            edit_href = html.escape(url_for("alchemy_fm_bridge.home", edit=slug) + "#designer")
            edit_label = "Continue editing" if is_editing else "Edit station"
            edit_btn_class = "afm-btn afm-btn-primary" if is_editing else "afm-btn afm-btn-secondary"
            confirm_msg = f"Delete station {name} ({slug})? This removes it from Alchemy FM permanently."
            cards.append(
                f'<article class="{card_class}">'
                '<div class="afm-station-card-head">'
                f"<div><h3 class='afm-station-name'>{html.escape(name)}</h3>"
                f"<div class='afm-station-slug'>{html.escape(slug)} · id {station_id}</div></div>"
                f"{on_air_badge}"
                "</div>"
                f"<p class='afm-station-programming'><strong>{html.escape(type_label)}</strong>"
                f"{html.escape(detail or '—')}</p>"
                f'<div class="afm-station-stats">{profile_badge}'
                f'<span class="afm-badge afm-badge-queue">{html.escape(queued)} queued</span>'
                f"{living_badge}</div>"
                '<div class="afm-station-actions">'
                f'<a href="{edit_href}" class="{edit_btn_class}">{html.escape(edit_label)}</a>'
                f'<form method="post" style="margin:0;" onsubmit="return confirm({json.dumps(confirm_msg)});">'
                f'<input type="hidden" name="action" value="delete">'
                f'<input type="hidden" name="station_id" value="{station_id}">'
                f'<input type="hidden" name="delete_slug" value="{html.escape(slug)}">'
                '<button type="submit" class="afm-btn afm-btn-danger">Delete</button>'
                "</form></div></article>"
            )
        cards.append("</div>")
        cards = "".join(cards)

    title = "Other stations" if editing_slug else "Your stations"
    note = (
        "Switch stations without losing your place — each opens in the designer above."
        if editing_slug
        else "Pick a station to edit, or create a new channel below."
    )
    new_channel = ""
    if not editing_slug:
        new_channel = (
            f'<a href="{html.escape(url_for("alchemy_fm_bridge.home", new="1") + "#designer")}" '
            'class="afm-btn afm-btn-primary">+ New channel</a>'
        )
    return (
        f'<section class="afm-section" id="stations">'
        '<div class="afm-section-head">'
        f"<div><h2 class='afm-section-title'>{html.escape(title)}</h2>"
        f"<p class='afm-section-note'>{html.escape(note)}</p></div>"
        f"{new_channel}"
        "</div>"
        f"{cards}"
        "</section>"
    )


def _channels_table_html() -> str:
    return _stations_section_html()


def _form_values_from_profile(profile: dict[str, Any]) -> dict[str, Any]:
    station = profile.get("station") or {}
    programming = profile.get("programming") or {}
    ptype = programming.get("type", "clap_query")
    values: dict[str, Any] = {
        "programming_type": ptype,
        "name": station.get("name", ""),
        "slug": station.get("slug", ""),
        "description": station.get("description", ""),
        "icecast_mount": station.get("icecast_mount", ""),
        "refresh_mode": (profile.get("refresh") or {}).get("mode", "similar_to_last"),
        "queue_target": station.get("queue_target", 30),
        "refresh_threshold": station.get("refresh_threshold", 10),
        "artist_separation_minutes": station.get("artist_separation_minutes", 90),
        "enabled": station.get("enabled", True),
        "bootstrap_queue": station.get("bootstrap_queue", True),
        "preview_limit": programming.get("limit", PREVIEW_LIMIT_DEFAULT),
        "saved_anchor_id": profile.get("anchor_id") or "",
    }
    filters = profile.get("filters") or {}
    for key in ("tempo_min", "tempo_max", "energy_min", "energy_max"):
        val = filters.get(key)
        if val is not None:
            values[f"filter_{key}"] = val
    living = profile.get("living") or {}
    values["living_enabled"] = bool(living.get("enabled"))
    values["living_auto_add"] = bool(living.get("auto_add_on_analyze", living.get("enabled")))
    values["living_auto_refresh"] = bool(living.get("auto_refresh_alchemy", living.get("enabled")))
    if ptype == "clap_query":
        values["clap_query"] = programming.get("query", "")
    elif ptype == "lyrics_query":
        values["lyrics_query"] = programming.get("query", "")
    elif ptype == "mood_centroid":
        values["mood_name"] = programming.get("mood", "")
        values["centroid_index"] = programming.get("centroid_index", "")
    elif ptype == "alchemy_anchor":
        values["anchor_id"] = programming.get("anchor_id", "")
    elif ptype == "similar_seed":
        values["seed_id"] = programming.get("seed_id", "")
    return values


def _page_script(mood_centroids: dict[str, Any] | None = None) -> str:
    mood_json = json.dumps(mood_centroids or {})
    return f"""
<script type="application/json" id="mood-centroids-data">{mood_json}</script>
<script>
(function() {{
  const typeSelect = document.getElementById('programming_type');
  const moodDataEl = document.getElementById('mood-centroids-data');
  const moodData = moodDataEl ? JSON.parse(moodDataEl.textContent || '{{}}') : {{}};
  const sections = {{
    clap_query: document.getElementById('field-clap'),
    lyrics_query: document.getElementById('field-lyrics'),
    mood_centroid: document.getElementById('field-mood'),
    alchemy_anchor: document.getElementById('field-anchor'),
    similar_seed: document.getElementById('field-seed'),
  }};
  function syncType() {{
    if (!typeSelect) return;
    const t = typeSelect.value;
    Object.entries(sections).forEach(([key, el]) => {{
      if (!el) return;
      el.hidden = key !== t;
    }});
  }}
  function clusterLabel(meta, idx) {{
    const index = meta.index != null ? meta.index : idx;
    let label = 'Cluster ' + index;
    const tags = meta.top_tags || meta.tags || meta.label;
    if (Array.isArray(tags) && tags.length) {{
      label = tags.slice(0, 3).join(', ');
      if (meta.n_songs) label += ' (' + meta.n_songs + ' tracks)';
    }} else if (typeof tags === 'string' && tags) {{
      label = tags;
    }}
    return label;
  }}
  function fillClusters() {{
    const moodSelect = document.querySelector('select[name="mood_name"]');
    const clusterSelect = document.getElementById('centroid_index');
    if (!moodSelect || !clusterSelect) return;
    const mood = moodSelect.value;
    const prev = clusterSelect.value;
    clusterSelect.innerHTML = '<option value="">Choose cluster…</option>';
    const list = moodData[mood];
    if (!Array.isArray(list)) return;
    list.forEach((meta, idx) => {{
      if (!meta || typeof meta !== 'object') return;
      const opt = document.createElement('option');
      const clusterIdx = meta.index != null ? String(meta.index) : String(idx);
      opt.value = clusterIdx;
      opt.textContent = clusterLabel(meta, idx);
      if (clusterIdx === prev) opt.selected = true;
      clusterSelect.appendChild(opt);
    }});
  }}
  if (typeSelect) {{
    typeSelect.addEventListener('change', syncType);
    syncType();
  }}
  const moodSelect = document.querySelector('select[name="mood_name"]');
  if (moodSelect) {{
    moodSelect.addEventListener('change', fillClusters);
    fillClusters();
  }}
  if (location.hash === '#designer') {{
    const target = document.getElementById('designer');
    if (target) target.scrollIntoView({{ behavior: 'smooth', block: 'start' }});
  }}
}})();
</script>
"""


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@bp.route("/", methods=["GET", "POST"])
def home():
    flash = ""
    preview_tracks: list[dict[str, Any]] = []
    values: dict[str, Any] = {
        "programming_type": "clap_query",
        "refresh_mode": "similar_to_last",
        "preview_limit": PREVIEW_LIMIT_DEFAULT,
        "queue_target": 30,
        "refresh_threshold": 10,
        "artist_separation_minutes": 90,
        "enabled": True,
        "bootstrap_queue": True,
    }

    if request.method == "GET":
        edit_slug = (request.args.get("edit") or "").strip()
        if edit_slug:
            try:
                values, preview_tracks, channel_name = _apply_loaded_channel(edit_slug)
            except ChannelDesignerError as exc:
                flash = _flash_html(str(exc), "error")
        elif request.args.get("new"):
            flash = _flash_html("New channel — design programming, preview tracks, then deploy.", "ok")

    if request.method == "POST":
        action = (request.form.get("action") or "preview").strip()

        if action == "edit":
            load_slug = (request.form.get("load_slug") or "").strip()
            if load_slug:
                return redirect(url_for("alchemy_fm_bridge.home", edit=load_slug) + "#designer")
        elif action == "new_channel":
            return redirect(url_for("alchemy_fm_bridge.home", new=1) + "#designer")
        elif action == "delete":
            try:
                station_id = int(request.form.get("station_id") or "0")
                delete_slug = (request.form.get("delete_slug") or "").strip()
                if station_id <= 0:
                    raise ChannelDesignerError("Invalid station id for delete.")
                _client().delete_station(station_id)
                _delete_local_channel(delete_slug)
                flash = _flash_html(
                    f"Deleted station '{delete_slug or station_id}' from Alchemy FM.",
                    "ok",
                )
                logger.info("alchemy_fm_bridge deleted station id=%s slug=%s", station_id, delete_slug)
            except ChannelDesignerError as exc:
                flash = _flash_html(str(exc), "error")
            except ValueError as exc:
                flash = _flash_html(str(exc), "error")
        else:
            values.update({k: request.form.get(k, values.get(k, "")) for k in request.form})
            values["enabled"] = request.form.get("enabled") == "on"
            values["bootstrap_queue"] = request.form.get("bootstrap_queue") == "on"
            values["living_enabled"] = request.form.get("living_enabled") == "on"
            values["living_auto_add"] = request.form.get("living_auto_add") == "on"
            values["living_auto_refresh"] = request.form.get("living_auto_refresh") == "on"

            pick_seed = (request.form.get("pick_seed") or "").strip()
            if pick_seed:
                values["seed_id"] = pick_seed
                values["programming_type"] = "similar_seed"
                if request.form.get("seed_search"):
                    values["seed_search_results"] = _search_tracks(request.form.get("seed_search") or "")
            elif action == "search_seed":
                values["seed_search_results"] = _search_tracks(request.form.get("seed_search") or "")
            elif action == "test":
                try:
                    stations = _client().test_connection()
                    flash = _flash_html(f"Alchemy FM connected — {len(stations)} station(s) on air.", "ok")
                except ChannelDesignerError as exc:
                    flash = _flash_html(str(exc), "error")
            else:
                try:
                    profile = profile_from_form(request.form)
                    values = _form_values_from_profile(profile)
                    if (request.form.get("editing_slug") or "").strip():
                        values["editing_slug"] = request.form.get("editing_slug").strip()

                    if action == "preview":
                        raw = preview_programming(profile)
                        if not raw:
                            raise ChannelDesignerError("No tracks matched this programming.")
                        preview_tracks = apply_track_filters(enrich_preview(raw), profile)
                        if not preview_tracks:
                            raise ChannelDesignerError(
                                "Tracks matched programming but none passed your tempo/energy filters."
                            )
                        slug = profile["station"]["slug"]
                        item_ids = [t["item_id"] for t in preview_tracks]
                        _record_audition(slug, item_ids)
                        if (profile.get("living") or {}).get("enabled"):
                            _add_to_pool(slug, item_ids, source="preview")
                        _save_channel(profile, preview_ids=item_ids)
                        flash = _flash_html(
                            f"Preview ready — {len(preview_tracks)} tracks from AudioMuse. "
                            "Review below, then deploy to Alchemy FM.",
                            "ok",
                        )
                    elif action == "push":
                        raw = preview_programming(profile)
                        if not raw:
                            raise ChannelDesignerError(
                                "No tracks to deploy. Preview programming first or broaden your criteria."
                            )
                        preview_tracks = apply_track_filters(enrich_preview(raw), profile)
                        if not preview_tracks:
                            raise ChannelDesignerError(
                                "No tracks passed your filters. Relax tempo/energy bounds or preview again."
                            )
                        payload = channel_profile_to_alchemy_payload(profile, preview_tracks)
                        slug = payload["slug"]
                        item_ids = [t["item_id"] for t in preview_tracks]
                        _record_audition(slug, item_ids)
                        if (profile.get("living") or {}).get("enabled"):
                            _add_to_pool(slug, item_ids, source="preview")
                        station, push_action = _client().push_station(
                            payload,
                            slug=slug,
                            bootstrap=bool(payload.get("bootstrap_queue")),
                        )
                        _save_channel(
                            profile,
                            preview_ids=item_ids,
                            station=station,
                            action=push_action,
                        )
                        anchor_note = ""
                        if profile["programming"]["type"] not in DIRECT_ALCHEMY_TYPES:
                            anchor_note = (
                                f" Created Song Alchemy anchor {profile.get('anchor_id')} for 24/7 refill."
                            )
                        flash = _flash_html(
                            f"Channel '{station.get('name')}' {push_action} on Alchemy FM "
                            f"(id {station.get('id')}).{anchor_note}",
                            "ok",
                        )
                        values = _form_values_from_profile(profile)
                        values["editing_slug"] = slug
                        logger.info(
                            "alchemy_fm_bridge deployed slug=%s action=%s anchor=%s",
                            slug,
                            push_action,
                            profile.get("anchor_id"),
                        )
                except ChannelDesignerError as exc:
                    slug = (
                        request.form.get("editing_slug")
                        or request.form.get("slug")
                        or _slugify(request.form.get("name") or "channel")
                    ).strip()
                    _record_channel_error(slug, str(exc))
                    flash = _flash_html(str(exc), "error")

    editing_slug = (values.get("editing_slug") or "").strip()
    stations_html = _stations_section_html(editing_slug or None)
    edit_bar = _edit_toolbar_html(values)
    designer_anchor = "" if editing_slug else '<div id="designer"></div>'
    designer_heading = (
        "<div class='afm-section-head' style='margin-top:0.5rem;'>"
        "<div><h2 class='afm-section-title'>Channel designer</h2>"
        "<p class='afm-section-note'>Program the vibe, preview tracks, then deploy to Alchemy FM.</p></div>"
        "</div>"
        if not editing_slug
        else ""
    )
    preview_block = (
        "<fieldset class='afm-designer-panel'>"
        "<legend><strong>Preview</strong></legend>"
        f"{_preview_table_html(preview_tracks)}"
        "</fieldset>"
    )
    audition_block = (
        "<fieldset class='afm-designer-panel'>"
        "<legend><strong>Audition history</strong></legend>"
        f"{_audition_history_html(editing_slug or None)}"
        "</fieldset>"
    )
    designer_form = (
        f"{designer_anchor}"
        f"{designer_heading}"
        "<form method='post' id='afm-designer-form' class='afm-designer-form' style='display:grid;gap:0.5rem;'>"
        f"{_programming_fields_html(values)}"
        f"{_filters_fields_html(values)}"
        f"{_living_fields_html(values)}"
        f"{_deploy_fields_html(values)}"
        "</form>"
        f"{preview_block}"
        f"{audition_block}"
    )

    if editing_slug:
        main_flow = f"{edit_bar}{designer_form}{stations_html}"
    else:
        main_flow = f"{stations_html}{designer_form}"

    body = (
        f"{_page_styles()}"
        '<div class="afm-shell">'
        f"<p class='afm-lede'>Channel Designer v{PLUGIN_VERSION} — design in AudioMuse, broadcast on Alchemy FM.</p>"
        f"{flash}"
        f"{main_flow}"
        "</div>"
        f"{_page_script(_mood_centroids_data())}"
    )
    return render_page(body, title="Alchemy FM Channel Designer")


@bp.route("/settings", methods=["GET", "POST"])
def settings():
    if request.method == "POST":
        set_setting("alchemyfm_url", (request.form.get("alchemyfm_url") or "").strip().rstrip("/"))
        set_setting("alchemyfm_username", (request.form.get("alchemyfm_username") or "admin").strip())
        password = request.form.get("alchemyfm_password")
        if password:
            set_setting("alchemyfm_password", password)
        token = request.form.get("audiomuse_api_token")
        if token:
            set_setting("audiomuse_api_token", token.strip())
        api_url = request.form.get("audiomuse_api_url")
        if api_url is not None:
            set_setting("audiomuse_api_url", api_url.strip().rstrip("/"))
        return redirect(manage_plugins_url())

    alchemyfm_url = get_setting("alchemyfm_url", "")
    alchemyfm_username = get_setting("alchemyfm_username", "admin")
    audiomuse_api_token = get_setting("audiomuse_api_token", "")
    audiomuse_api_url = get_setting("audiomuse_api_url", "")
    body = (
        "<form method='post' style='display:grid;gap:1rem;max-width:36rem;'>"
        "<p>Connect to your Alchemy FM broadcast instance. Credentials match "
        "<code>ADMIN_USERNAME</code> / <code>ADMIN_PASSWORD</code> in Alchemy FM.</p>"
        "<p class='hint'><strong>Cloudflare / public URL:</strong> If Alchemy FM is behind Cloudflare, allow "
        "server-to-server access to <code>/api/admin/*</code> from your AudioMuse host (WAF skip rule or "
        "bypass Bot Fight Mode). Otherwise use a LAN/direct URL that does not go through Cloudflare "
        "(e.g. <code>http://192.168.1.100:8080</code>).</p>"
        "<div><label>Alchemy FM URL</label>"
        f"<input name='alchemyfm_url' required placeholder='https://alchemyfm.example.com' "
        f"value='{html.escape(alchemyfm_url)}'></div>"
        "<div><label>Admin username</label>"
        f"<input name='alchemyfm_username' value='{html.escape(alchemyfm_username)}'></div>"
        "<div><label>Admin password</label>"
        "<input name='alchemyfm_password' type='password' autocomplete='new-password' "
        "placeholder='Leave blank to keep current password'></div>"
        "<div><label>AudioMuse API token (optional)</label>"
        f"<input name='audiomuse_api_token' type='password' autocomplete='new-password' "
        f"placeholder='Only if AudioMuse auth is enabled' value='{html.escape(audiomuse_api_token)}'></div>"
        "<div><label>AudioMuse API URL (optional, for worker/cron)</label>"
        f"<input name='audiomuse_api_url' placeholder='http://192.168.1.100:8387' "
        f"value='{html.escape(audiomuse_api_url)}'>"
        "<p class='hint'>Living-channel cron and <code>on_song_analyzed</code> run on the worker and "
        "need a URL the worker can reach (LAN IP, not <code>localhost</code>). Leave blank to use "
        "AudioMuse control host/port from the environment.</p></div>"
        "<button type='submit'>Save</button>"
        "</form>"
    )
    return render_page(body, title="Alchemy FM Bridge Settings")


def register(ctx):
    ctx.on_install(migrate)
    ctx.add_blueprint(bp)
    ctx.add_menu_item("Alchemy FM", "alchemy_fm_bridge.home", admin_only=True)
    ctx.on_song_analyzed(on_song_analyzed)
    ctx.add_cron_task("refresh_living", refresh_living_channels)
